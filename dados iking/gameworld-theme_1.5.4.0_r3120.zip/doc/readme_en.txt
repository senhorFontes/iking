﻿Presthemes GameWorld Prestashop Theme
by PresThemes.com
Version Prestashop: 1.5.1.0, 1.5.3.x, 1.5.4.x

Userguide: http://presthemes.com/manual/gameworld_1.5/
	
Or contact to support@presthemes.com 