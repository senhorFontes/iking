<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blocksearch}gameworld>blocksearch-top_13348442cc6a27032d2b4aa28b75a5d3'] = 'Rechercher';
$_MODULE['<{blocksearch}gameworld>blocksearch-top_09aa42614665803ac1b1f0e5fade0efe'] = 'rechercher ensemble du';
