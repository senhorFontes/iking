<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockuserinfo}gameworld>blockuserinfo_12641546686fe11aaeb3b3c43a18c1b3'] = 'Votre panier d\'achat';
$_MODULE['<{blockuserinfo}gameworld>blockuserinfo_f237c29fb26b65493ab03775f2051f60'] = 'Panie:';
$_MODULE['<{blockuserinfo}gameworld>blockuserinfo_f5bf48aa40cad7891eb709fcf1fde128'] = 'produit';
$_MODULE['<{blockuserinfo}gameworld>blockuserinfo_86024cad1e83101d97359d7351051156'] = 'produits';
$_MODULE['<{blockuserinfo}gameworld>blockuserinfo_9e65b51e82f2a9b9f72ebe3e083582bb'] = '(vide)';
$_MODULE['<{blockuserinfo}gameworld>blockuserinfo_a421826a85be98f0451223f0e7454715'] = 'Accueil';
$_MODULE['<{blockuserinfo}gameworld>blockuserinfo_4b877ba8588b19f1b278510bf2b57ebb'] = 'Me déconnecter';
$_MODULE['<{blockuserinfo}gameworld>blockuserinfo_0323de4f66a1700e2173e9bcdce02715'] = 'Déconnecter';
$_MODULE['<{blockuserinfo}gameworld>blockuserinfo_adb831a7fdd83dd1e2a309ce7591dff8'] = 'Invité';
$_MODULE['<{blockuserinfo}gameworld>blockuserinfo_99dea78007133396a7b8ed70578ac6ae'] = 'Connexion';
$_MODULE['<{blockuserinfo}gameworld>blockuserinfo_a0623b78a5f2cfe415d9dbbd4428ea40'] = 'Votre compte';
$_MODULE['<{blockuserinfo}gameworld>blockuserinfo_bea8d9e6a0d57c4a264756b4f9822ed9'] = 'Mon compte';
