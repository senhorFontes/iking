<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockpermanentlinks}gameworld>blockpermanentlinks-header_8cf04a9734132302f96da8e113e80ce5'] = 'Masion';
$_MODULE['<{blockpermanentlinks}gameworld>blockpermanentlinks-header_b4f95c1ea534936cc60c6368c225f480'] = 'Toutes les promos';
$_MODULE['<{blockpermanentlinks}gameworld>blockpermanentlinks-header_d1aa22a3126f04664e0fe3f598994014'] = 'Promostion';
$_MODULE['<{blockpermanentlinks}gameworld>blockpermanentlinks-header_e1da49db34b0bdfdddaba2ad6552f848'] = 'plan du site';
$_MODULE['<{blockpermanentlinks}gameworld>blockpermanentlinks-header_5813ce0ec7196c492c97596718f71969'] = 'Plan du site';
$_MODULE['<{blockpermanentlinks}gameworld>blockpermanentlinks-header_2f8a6bf31f3bd67bd2d9720c58b19c9a'] = 'contacter';
$_MODULE['<{blockpermanentlinks}gameworld>blockpermanentlinks-header_bbaff12800505b22a853e8b7f4eb6a22'] = 'Contacter';
