<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockcurrencies}gameworld>blockcurrencies_1af0389838508d7016a9841eb6273962'] = 'Devise';
