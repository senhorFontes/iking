<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blocklanguages}gameworld>blocklanguages_8512ae7d57b1396273f76fe6ed341a23'] = 'langua';
