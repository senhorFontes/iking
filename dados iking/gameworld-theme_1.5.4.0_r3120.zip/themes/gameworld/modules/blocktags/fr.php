<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blocktags}gameworld>blocktags_7b247f76c157672226ab7131e6ac91c0'] = 'Tags Populaires';
$_MODULE['<{blocktags}gameworld>blocktags_49fa2426b7903b3d4c89e2c1874d9346'] = 'Plus d\'informations sur';
$_MODULE['<{blocktags}gameworld>blocktags_70d5e9f2bb7bcb17339709134ba3a2c6'] = 'Pas de tags de spécifiés';
