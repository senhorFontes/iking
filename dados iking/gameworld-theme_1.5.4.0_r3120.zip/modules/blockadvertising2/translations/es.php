<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{blockadvertising}prestashop>blockadvertising_fd4c71c948857cce596a69fbaea7426b'] = 'Bloque de publicidad';
$_MODULE['<{blockadvertising}prestashop>blockadvertising_a7339a98fd0ebea5ed982f92eed11c70'] = 'Añadir un bloque para mostrar la publicidad';
$_MODULE['<{blockadvertising}prestashop>blockadvertising_226ed577d0eff50725be6447bcd5a2f0'] = 'error al desplazar el fichero uploado';
$_MODULE['<{blockadvertising}prestashop>blockadvertising_6e7be6d836003f069c00cd217660913b'] = 'Configuración del bloque de publicidad';
$_MODULE['<{blockadvertising}prestashop>blockadvertising_83b5a65e518c21ed0a5f2b383dd9b617'] = 'Eliminar la imagen';
$_MODULE['<{blockadvertising}prestashop>blockadvertising_706bebc78ad992a07e4c1ce0f39def81'] = 'Ninguna imagen';
$_MODULE['<{blockadvertising}prestashop>blockadvertising_8c38cf08a0d0a01bd44c682479432350'] = 'Cambiar la imagen';
$_MODULE['<{blockadvertising}prestashop>blockadvertising_56d9dfa26d7848a3fbcd2ae3091d38d9'] = 'La imagen se mostrará como 155x163';
$_MODULE['<{blockadvertising}prestashop>blockadvertising_9ce38727cff004a058021a6c7351a74a'] = 'Enlace de la imagen';
$_MODULE['<{blockadvertising}prestashop>blockadvertising_b78a3223503896721cca1303f776159b'] = 'Título';
$_MODULE['<{blockadvertising}prestashop>blockadvertising_f9ab05454998236921a6b0e281fae632'] = 'Validar';

?>