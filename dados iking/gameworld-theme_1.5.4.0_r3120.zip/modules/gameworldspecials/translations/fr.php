<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{gameworldspecials}prestashop>gameworldspecials_d1aa22a3126f04664e0fe3f598994014'] = 'Promotion';
